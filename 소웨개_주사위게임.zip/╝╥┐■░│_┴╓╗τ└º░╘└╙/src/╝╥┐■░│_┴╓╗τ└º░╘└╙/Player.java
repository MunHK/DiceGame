package 소웨개_주사위게임;

public class Player {
	String name;
	Dice dice1 = new Dice();
	Dice dice2 = new Dice();
	
	Player(){}
	
	Player(String n){
		this.name=n;
	}
	
	void PrintPlayer(){
		System.out.println("이름 : "+name);
		System.out.println("주사위1 수 : ");
		dice1.printNum();
		System.out.println("주사위2 수 : ");
		dice2.printNum();
	}
}
