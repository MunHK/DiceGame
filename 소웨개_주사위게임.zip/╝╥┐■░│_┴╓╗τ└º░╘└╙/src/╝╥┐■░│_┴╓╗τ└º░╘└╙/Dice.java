package 소웨개_주사위게임;

import java.util.Random;

public class Dice {
	Random r = new Random();
	int num=r.nextInt(6)+1;
	
	int getNum() {
		return num;
	}
	void printNum() {
		System.out.println(num);
	}
}
