package 소웨개_주사위게임;

import java.util.Scanner;

public class DiceGame {

	public static void main(String[] args) {
		play();
	}
	
	static void play() {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("====주사위 게임====");
		System.out.println("플레이어1 이름입력 : ");
		String name1 = sc.next();
		System.out.println("플레이어2 이름입력 : ");
		String name2 = sc.next();
		System.out.println("게임을 시작하겠습니까(시작 : 1 취소 : 2) ?");
		int answer = sc.nextInt();
		
		if(answer==1) {
			Player p1 = new Player(name1);
			Player p2 = new Player(name2);
			int result=((p1.dice1.num+p1.dice2.num)>(p2.dice1.num+p2.dice2.num)) ? 1 : 2;

			System.out.printf("%s : %d,%d    %s : %d,%d\n",p1.name,p1.dice1.num,p1.dice2.num,p2.name,p2.dice1.num,p2.dice2.num);
			
			if(p1.dice1.num+p1.dice2.num == p2.dice1.num+p2.dice2.num)
				result = 0;
			
			switch(result) {
			case 0:
				int num1 = p1.dice1.num>p1.dice2.num ? p1.dice1.num : p1.dice2.num;
				int num2 = p2.dice1.num>p2.dice2.num ? p2.dice1.num : p2.dice2.num;
				if(num1 > num2)
					System.out.println(p1.name+" 승리");
				else
					System.out.println(p2.name+" 승리");
				break;
			case 1:
				System.out.println(p1.name+" 승리");
				break;
			case 2:
				System.out.println(p2.name+" 승리");
				break;
			default:
				System.out.println("오류 발생");
			}
		}
		else {
			System.out.println("게임 종료!");
		}
	}

}

